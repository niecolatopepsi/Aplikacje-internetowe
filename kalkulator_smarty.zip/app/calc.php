<?php
require_once dirname(__FILE__).'/../config.php';
require_once _ROOT_PATH.'/lib/Smarty.class.php';

function getParams(&$form){
    $form['kwota'] = isset($_REQUEST['kwota']) ? $_REQUEST['kwota'] : null;
    $form['oprocentowanie'] = isset($_REQUEST['oprocentowanie']) ? $_REQUEST['oprocentowanie'] : null;
    $form['czas'] = isset($_REQUEST['czas']) ? $_REQUEST['czas'] : 24;
}

function validate(&$form, &$messages, &$infos, &$hide_intro){
    if (!(isset($form['kwota']) && isset($form['oprocentowanie']) && isset($form['czas']))) return false;

    $hide_intro = true;

    if ($form['kwota'] == "") {
        $messages[] = 'Brak podanej kwoty kredytu';
    }
    if ($form['oprocentowanie'] == "") {
        $messages[] = 'Brak podanej wysokości oprocentowania';
    }

    if (count($messages) != 0) 
        return false;
    
    if (!is_numeric($form['kwota'])) {
        $messages[] = 'Wartość w polu kwota kredytu musi być liczbą';
    }
    
    if (!is_numeric($form['oprocentowanie'])) {
        $messages[] = 'Wartość w polu wysokość oprocentowania musi być liczbą';
    }   
    
    if (!is_numeric($form['czas'])) {
        $messages[] = 'Wartość w polu okres spłaty musi być liczbą!';
    }

    if (count($messages) != 0) 
        return false;
    else {
        $infos[] = 'Paramerty przekazane.';
        return true;    
    }
}

function obliczenia(&$form, &$infos){   
    $infos[] = 'Przekazane parametry są poprawne. Obliczam.';
    $form['rata'] = $form['kwota'] / $form['czas'] + $form['kwota'] / $form['czas'] * $form['oprocentowanie'] / 100;
    $form['rata'] = round($form['rata'], 2); 
}

$messages = array();
$infos = array();
$hide_intro = false;
$form = null;

getParams($form);
if (validate($form, $messages, $infos, $hide_intro)) { 
    obliczenia($form, $infos);
}

$smarty = new Smarty();

$smarty->assign('app_url', _APP_URL);
$smarty->assign('root_path', _ROOT_PATH);
$smarty->assign('page_title', 'Prosty kalkulator kredytowy');
$smarty->assign('page_description', 'Kalkulator z wykorzystaniem Smarty');
$smarty->assign('page_header', 'Szablony Smarty');
$smarty->assign('hide_intro', $hide_intro);
$smarty->assign('form', $form);
$smarty->assign('messages', $messages);
$smarty->assign('infos', $infos);

$smarty->display(_ROOT_PATH.'/app/calc_view.html');
?>
