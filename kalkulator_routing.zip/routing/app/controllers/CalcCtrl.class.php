<?php

namespace app\controllers;

use app\forms\CalcTab;
use app\transfer\CalcResult;

    
                class CalcCtrl
                {
                   
                    private $tab;
                    private $result;
                
                   
                    public function __construct()
                    {
                        $this->tab = new CalcTab();
                        $this->result = new CalcResult();             
                    }
                    
                    
                    
                    
                    


                    public function getParams()
			{
				$this->tab->kwota = getFromRequest('kwota');
				$this->tab->czas = getFromRequest('czas');
				$this->tab->oprocentowanie = getFromRequest('oprocentowanie');
			}
                        
                        
                    
                    
                    
                    
                    public function validate()
		{
						
			if (  (!isset($this->tab->kwota) || !isset($this->tab->oprocentowanie) || !isset($this->tab->czas)) ) return false;  //po co to jest!
		
			if($this->tab->kwota =="")   getMessages()->addError("Nie podano kwoty");
			if($this->tab->oprocentowanie =="")   getMessages()->addError("Nie podano oprocentowania");
			
                        if(getMessages()->isGood())
                        {
                            if( !is_numeric($this->tab->kwota))   getMessages()->addError("Podana wartość kwoty nie jest liczbą!");
			if( !is_numeric($this->tab->oprocentowanie)) getMessages()->addError("Podana wartość oprocentowania nie jest liczbą");
                        return true;
                            
                        } return getMessages()->isGood();
                }
                
                
               
                        
                        
                        public function action_calcCompute()
			{
                            
                            $this->getParams();
                            
                            if($this->validate())
                            {
                    
				getMessages()->addInfo("Obliczanie");
				$this->result->result= $this->tab->kwota/$this->tab->czas + $this->tab->kwota/$this->tab->czas*$this->tab->oprocentowanie/100;
                                $this->result->result = round($this->result->result,2);
                                
                                getMessages()->addInfo('Wykonano obliczenia');
                            }
                            $this->generateView();
			}
			
			
			public function action_calcShow(){
		getMessages()->addInfo('Witaj w kalkulatorze kredytowym');
		$this->generateView();
	}
					
		
                        
                        
              
public function       generateView(){
    
                getSmarty()->assign('page_title','router');
		getSmarty()->assign('page_description','...');
		getSmarty()->assign('page_header','...');
                
                
               getSmarty()->assign('user',unserialize($_SESSION['user']));
				
		
                
	       getSmarty()->assign('tab',$this->tab);
	       getSmarty()->assign('result',$this->result);
		
		getSmarty()->display('Cal_view.tpl'); 
	}


    

}





