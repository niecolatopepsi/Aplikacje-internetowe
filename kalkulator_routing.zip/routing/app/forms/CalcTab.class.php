<?php
        namespace app\forms;
    class CalcTab{
        
        public $kwota;
        public $czas;
        public $oprocentowanie;
        
        
    }

