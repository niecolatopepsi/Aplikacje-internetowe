<?php

namespace app\transfer;

class CalcResult{
    
    public $result;
}

