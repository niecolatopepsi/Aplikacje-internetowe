<?php

namespace app\controllers;

class DbHistory
{
    public function action_showDbHistory()
    {
        if (!inRole('admin')) {
            getMessages()->addError("Dozowlone tylko dla admin");
            forwardTo('calcShow');
        } else {
            getMessages()->addInfo('Witam admina');
            $this->getFromDb();
            $this->generateView();
        }
    }

    private function getFromDb()
    {
        # wywołanie obiektu Medoo
        $data = getDb()->select("wynik", [
            "idwynik",
            "kwota",
            "czas",
            "oprocentowanie",
            "result",
            "data",
        ]);
        getSmarty()->assign('data', $data);
    }

    public function generateView()
    {
        getSmarty()->assign('user', unserialize($_SESSION['user']));
        getSmarty()->assign('page_title', 'Historia');
        getSmarty()->display('History_View_Db.tpl');
    }
}