<?php
class CalcForm {
	public $kwota;
	public $oprocentowanie;
	public $czas;
} 